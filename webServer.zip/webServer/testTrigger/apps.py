from django.apps import AppConfig


class TesttriggerConfig(AppConfig):
    name = 'testTrigger'
